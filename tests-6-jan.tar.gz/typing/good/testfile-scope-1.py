if 1 < 2:
   x = 1
else:
   y = 2
if 1 < 2:
   print(x)
else:
   print(y)
