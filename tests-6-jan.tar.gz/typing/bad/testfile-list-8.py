
def f():
    x = 1
def g():
    return x
print(0)
