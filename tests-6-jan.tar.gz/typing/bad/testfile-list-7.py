
def f():
    x = 1
print(x)
