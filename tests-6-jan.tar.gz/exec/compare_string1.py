# true
print("" == "")
print("" < "a")
print("b" < "c")
print("ab" >= "ab")
print("" != "a")
print("abc" == "abc")
# false
print("a" > "b")
print("" > "b")
print("abc" <= "ab")
