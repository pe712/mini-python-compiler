x = 42
print(x)
for x in [1,2,3]:
    print(x)
print(x)
