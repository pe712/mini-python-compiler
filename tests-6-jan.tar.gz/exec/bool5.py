print(True)
print(False)
print(True and False)
print(True or False)
